﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COPPEL
{
    public partial class Form1 : Form
    {
        private COPPELDataSet datos;

        private COPPELDataSetTableAdapters.EmpleadoTableAdapter empleadoTA;
        private COPPELDataSetTableAdapters.centrotrabajoTableAdapter centroTrabajoTA;
        private COPPELDataSetTableAdapters.PuestoTableAdapter puestosTA;
        private COPPELDataSetTableAdapters.DirectivosTableAdapter directivosTA;
        public Form1()
        {
            InitializeComponent();
            datos = new COPPELDataSet();
            empleadoTA = new COPPELDataSetTableAdapters.EmpleadoTableAdapter();
            centroTrabajoTA = new COPPELDataSetTableAdapters.centrotrabajoTableAdapter();
            puestosTA = new COPPELDataSetTableAdapters.PuestoTableAdapter();
            directivosTA = new COPPELDataSetTableAdapters.DirectivosTableAdapter();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
            // Llenar las tablas desde la base de datos
                empleadoTA.Fill(datos.Empleado);
                centroTrabajoTA.Fill(datos.centrotrabajo);
                puestosTA.Fill(datos.Puesto);
                directivosTA.Fill(datos.Directivos);

                // Enlazar los DataGridView con los DataTable
                dgvEmpleado.DataSource = datos.Empleado;
                dgvCentroTrabajo.DataSource = datos.centrotrabajo;
                dgvPuestos.DataSource = datos.Puesto;
                dgvDirectivos.DataSource = datos.Directivos;
            }
            catch (Exception ex)
            {
                    MessageBox.Show(
                        "Error al cargar los datos desde la base de datos:\n" + ex.Message,
                        "Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                        );
            }
        }
     }
}